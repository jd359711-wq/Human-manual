# The Human Manual: workflow lab

This exercise goes with Chapter 29, "Design and Test an AI Workflow." It uses Python and SQLite to model approval, a simulated outbox and what happens when the same trigger fires twice. The recipient and attachment are made up. Nothing here calls an AI service, connects an inbox or sends real email.

You need Python 3.9 or newer. Nothing else to install.

Extract the ZIP into a folder, open a terminal in that folder, and run:

```sh
python3 workflow_lab.py
python3 -m unittest test_workflow_lab.py
python3 capture_examples.py
```

On Windows, type `py` instead of `python3`.

1. The first command runs the simulation.
2. The second runs the 11 test cases. You should see `OK` at the end.
3. The third repeats the two recorded traces from Chapters 28 and 29. It opens a local loopback test server and a temporary SQLite database. It makes no outside request and delivers nothing.

For the attachment exercise, read `approval_trace` in `capture_examples.py`. Change the second attachment's bytes and predict which calls will be blocked. The recorded run in `observed_traces.json` shows a blocked send before fresh approval, one simulated delivery after approval and one outbox row after the original trigger is replayed.
