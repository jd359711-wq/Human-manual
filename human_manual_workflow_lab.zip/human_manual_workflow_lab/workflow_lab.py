"""Offline approval/state mechanics. No model, network, credentials or real email.
Run python3 workflow_lab.py. An optional database path preserves demonstration state.
Trusted approve() stands in for an authenticated review interface, not public access.
"""
import hashlib,json,sqlite3,tempfile,sys
from dataclasses import dataclass,asdict
from pathlib import Path

@dataclass(frozen=True)
class Attachment:
    name: str
    sha256: str

    @classmethod
    def from_bytes(cls, name, content):
        return cls(name, hashlib.sha256(content).hexdigest())

@dataclass(frozen=True)
class Draft:
    recipient:str
    subject:str
    body:str
    attachments: tuple[Attachment, ...] = ()

def digest(draft):
    return hashlib.sha256(json.dumps(asdict(draft),sort_keys=True,separators=(',',':')).encode()).hexdigest()

class Lab:
    def __init__(self,path):
        self.db=sqlite3.connect(str(path),timeout=10,isolation_level=None)
        self.db.executescript('''CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, payload TEXT NOT NULL, digest TEXT NOT NULL, approved TEXT, reviewer TEXT, status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS original_events(run_id TEXT PRIMARY KEY, digest TEXT NOT NULL);
        INSERT OR IGNORE INTO original_events SELECT id, digest FROM runs;
        CREATE TABLE IF NOT EXISTS outbox(run_id TEXT PRIMARY KEY,payload TEXT NOT NULL);''')
    def close(self):self.db.close()
    def create(self,run_id,draft):
        payload=json.dumps(asdict(draft),sort_keys=True);h=digest(draft)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT digest FROM original_events WHERE run_id=?',(run_id,)).fetchone()
            if row and row[0]!=h:raise ValueError('Run identifier already belongs to another input')
            if not row:
                self.db.execute('INSERT INTO runs VALUES(?,?,?,?,?,?)',(run_id,payload,h,None,None,'draft'))
                self.db.execute('INSERT INTO original_events VALUES(?,?)',(run_id,h))
            self.db.commit()
        except Exception:self.db.rollback();raise
    def edit(self,run_id,draft):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT status FROM runs WHERE id=?',(run_id,)).fetchone()
            if not row or row[0] in ('sent','uncertain'):raise ValueError('Missing or non-editable run')
            self.db.execute('UPDATE runs SET payload=?,digest=?,approved=NULL,reviewer=NULL,status=? WHERE id=?',(json.dumps(asdict(draft),sort_keys=True),digest(draft),'draft',run_id));self.db.commit()
        except Exception:self.db.rollback();raise
    def approve(self,run_id,expected_digest,reviewer):
        if not reviewer:raise ValueError('Reviewer required')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT digest,status FROM runs WHERE id=?',(run_id,)).fetchone()
            if not row or row[0]!=expected_digest or row[1] in ('sent','uncertain'):raise ValueError('Draft changed or cannot be approved')
            self.db.execute('UPDATE runs SET approved=digest,reviewer=?,status=? WHERE id=?',(reviewer,'approved',run_id));self.db.commit()
        except Exception:self.db.rollback();raise
    def revoke(self,run_id):
        self.db.execute('UPDATE runs SET approved=NULL,reviewer=NULL,status=? WHERE id=? AND status NOT IN (?,?)',('draft',run_id,'sent','uncertain'))
    def mark_uncertain(self,run_id):
        self.db.execute('UPDATE runs SET status=? WHERE id=? AND status=?',('uncertain',run_id,'approved'))
    def send_simulated(self,run_id):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row=self.db.execute('SELECT payload,digest,approved,reviewer,status FROM runs WHERE id=?',(run_id,)).fetchone()
            if not row:raise ValueError('Unknown run')
            payload,h,approved,reviewer,status=row
            if status=='sent':self.db.commit();return 'already recorded'
            if status!='approved' or approved!=h or not reviewer:raise ValueError('Exact current draft needs approval; uncertain actions need reconciliation')
            # Both effects share one LOCAL transaction only because delivery is simulated.
            self.db.execute('INSERT INTO outbox VALUES(?,?)',(run_id,payload))
            self.db.execute('UPDATE runs SET status=? WHERE id=?',('sent',run_id));self.db.commit();return 'recorded in simulated outbox'
        except Exception:self.db.rollback();raise
    def outbox_count(self):return self.db.execute('SELECT COUNT(*) FROM outbox').fetchone()[0]

def demo(path):
    lab=Lab(path);d=Draft('reviewer@example.invalid','Repair visit','Tuesday or Thursday after 4 p.m.?')
    lab.create('demo-repair',d)
    row=lab.db.execute('SELECT status FROM runs WHERE id=?',('demo-repair',)).fetchone()
    if row[0]!='sent':lab.approve('demo-repair',digest(d),'trusted-demo-reviewer')
    print(lab.send_simulated('demo-repair'));print(lab.send_simulated('demo-repair'));print('Simulated outbox rows:',lab.outbox_count());lab.close()

if __name__=='__main__':
    if len(sys.argv)>1:demo(Path(sys.argv[1]))
    else:
        with tempfile.TemporaryDirectory() as folder:demo(Path(folder)/'lab.sqlite')
