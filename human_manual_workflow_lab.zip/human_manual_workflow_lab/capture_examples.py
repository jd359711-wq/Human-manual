from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from pathlib import Path
from tempfile import TemporaryDirectory
from dataclasses import replace
import json
import sys
from workflow_lab import Attachment, Draft, Lab, digest


class DemoEndpoint(BaseHTTPRequestHandler):
    """Local fixture with deliberately different health and send outcomes."""

    def do_GET(self):
        self.respond(200, {"status": "ok"})

    def do_POST(self):
        self.respond(401, {"error": "missing_credential", "stage": "authorize"})

    def respond(self, status, body):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(body, separators=(",", ":")).encode())

    def log_message(self, *args):
        pass


def http_trace():
    with ThreadingHTTPServer(("127.0.0.1", 0), DemoEndpoint) as server:
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            root = f"http://127.0.0.1:{server.server_port}"
            result = []
            for method, path in [("GET", "/health"), ("POST", "/send")]:
                try:
                    response = urlopen(Request(root + path, method=method), timeout=3)
                except HTTPError as error:
                    response = error
                with response:
                    result.append(f"{method} {path} → {response.status}")
                    result.append(response.read().decode())
            return result
        finally:
            server.shutdown()
            thread.join()


def approval_trace():
    with TemporaryDirectory() as folder:
        lab = Lab(Path(folder) / "trace.sqlite")
        try:
            draft = Draft("reviewer@example.invalid", "Repair visit", "Please choose a day.",
                          (Attachment.from_bytes("estimate.txt", b"parts: 85"),))
            changed = replace(draft, attachments=(Attachment.from_bytes("estimate.txt", b"parts: 95"),))
            lab.create("event-01", draft)
            lab.approve("event-01", digest(draft), "fixture-reviewer")
            lab.edit("event-01", changed)
            result = ["Attachment bytes changed. Filename still estimate.txt."]
            try:
                lab.send_simulated("event-01")
            except ValueError as error:
                result.append("Send blocked: " + str(error))
            else:
                raise AssertionError("A changed draft unexpectedly sent")
            result.append(f"Outbox before fresh approval: {lab.outbox_count()}")
            lab.approve("event-01", digest(changed), "fixture-reviewer")
            result.append("After fresh approval: " + lab.send_simulated("event-01"))
            lab.create("event-01", draft)
            result.append("Original trigger replayed: " + lab.send_simulated("event-01"))
            result.append(f"Final outbox rows: {lab.outbox_count()}")
            return result
        finally:
            lab.close()


if __name__ == "__main__":
    print(json.dumps({"python": sys.version.split()[0], "http": http_trace(),
                      "approval": approval_trace()}, indent=2, ensure_ascii=False))
