import tempfile,unittest
from pathlib import Path
from dataclasses import replace
from workflow_lab import Attachment,Lab,Draft,digest

class Mechanics(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory();self.path=Path(self.folder.name)/'lab.sqlite';self.lab=Lab(self.path)
        self.d=Draft('one@example.invalid','subject','body',(Attachment.from_bytes('a.txt',b'original'),))
        self.lab.create('r1',self.d)
    def tearDown(self):self.lab.close();self.folder.cleanup()
    def approve(self):self.lab.approve('r1',digest(self.d),'trusted reviewer')
    def test_unapproved(self):
        with self.assertRaises(ValueError):self.lab.send_simulated('r1')
        self.assertEqual(self.lab.outbox_count(),0)
    def test_changes_invalidate(self):
        for field,value in [('recipient','two@example.invalid'),('subject','new'),('body','new'),('attachments',(Attachment.from_bytes('a.txt',b'edited'),))]:
            self.lab.edit('r1',self.d);self.approve();self.lab.edit('r1',replace(self.d,**{field:value}))
            with self.assertRaises(ValueError):self.lab.send_simulated('r1')
    def test_stale_review(self):
        self.lab.edit('r1',replace(self.d,body='changed'))
        with self.assertRaises(ValueError):self.approve()
    def test_duplicate_and_restart(self):
        self.approve();self.assertEqual(self.lab.send_simulated('r1'),'recorded in simulated outbox');self.lab.close();self.lab=Lab(self.path)
        self.assertEqual(self.lab.send_simulated('r1'),'already recorded');self.assertEqual(self.lab.outbox_count(),1)
    def test_duplicate_event(self):
        self.lab.create('r1',self.d);self.assertEqual(self.lab.db.execute('SELECT COUNT(*) FROM runs').fetchone()[0],1)
        with self.assertRaises(ValueError):self.lab.create('r1',replace(self.d,body='changed'))
    def test_original_event_replayed_after_edit(self):
        revised=replace(self.d,body='reviewed edit')
        self.lab.edit('r1',revised)
        self.lab.approve('r1',digest(revised),'trusted reviewer')
        self.lab.create('r1',self.d)
        self.assertEqual(self.lab.send_simulated('r1'),'recorded in simulated outbox')
        self.lab.create('r1',self.d)
        self.assertEqual(self.lab.send_simulated('r1'),'already recorded')
    def test_uncertain_never_blind_retry(self):
        self.approve();self.lab.mark_uncertain('r1')
        with self.assertRaises(ValueError):self.lab.send_simulated('r1')
        with self.assertRaises(ValueError):self.approve()
        self.assertEqual(self.lab.outbox_count(),0)
    def test_revoke(self):
        self.approve();self.lab.revoke('r1')
        with self.assertRaises(ValueError):self.lab.send_simulated('r1')
    def test_second_connection_duplicate(self):
        self.approve();other=Lab(self.path)
        try:
            self.lab.send_simulated('r1');self.assertEqual(other.send_simulated('r1'),'already recorded');self.assertEqual(other.outbox_count(),1)
        finally:other.close()
    def test_missing_reviewer(self):
        with self.assertRaises(ValueError):self.lab.approve('r1',digest(self.d),'')
    def test_sent_cannot_be_changed(self):
        self.approve();self.lab.send_simulated('r1')
        with self.assertRaises(ValueError):self.lab.edit('r1',replace(self.d,body='different'))

if __name__=='__main__':unittest.main()
